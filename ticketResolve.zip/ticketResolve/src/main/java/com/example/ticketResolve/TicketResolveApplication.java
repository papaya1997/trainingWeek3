package com.example.ticketResolve;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TicketResolveApplication {

	public static void main(String[] args) {
		SpringApplication.run(TicketResolveApplication.class, args);
	}

}
